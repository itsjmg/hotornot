jQuery( document ).ready( function( $ ) {
    // Handle clicks on HOT or NOT buttons
    $( '.hot-or-not-buttons' ).on( 'click', 'a', function( e ) {
        e.preventDefault();

        var button = $( this ),
            photo_id = button.closest( '.hot-or-not-buttons' ).data( 'photo-id' ),
            vote = button.hasClass( 'hot-button' ) ? 'hot' : 'not';

        // Save the user's vote
        $.post(
            hotOrNotAjax.ajaxurl,
            {
                action: 'hot_or_not_save_vote',
                hot_or_not_photo_id: photo_id,
                hot_or_not_vote: vote,
                hot_or_not_nonce: hotOrNotAjax.nonce
            }
        );

        // Load the next photo
        $.post(
            hotOrNotAjax.ajaxurl,
            {
                action: 'hot_or_not_load_next_photo',
                hot_or_not_current_photo_id: photo_id,
                hot_or_not_vote: vote,
                hot_or_not_nonce: hotOrNotAjax.nonce
            },
            function( response ) {
                $( '#post-' + photo_id ).fadeOut( 500, function() {
                    $( this ).remove();
                } );

                $( '#hot-or-not-container' ).append(
                    '<div id="post-' + response.data.photo_id + '" class="hot-or-not-photo" style="background-image: url(' + response.data.photo_url + ')">' +
                    '<div class="hot-or-not-buttons" data-photo-id="' + response.data.photo_id + '">' +
                    '<a href="#" class="hot-button">HOT</a>' +
                    '<a href="#" class="not-button">NOT</a>' +
                    '</div>' +
                    '</div>'
                );
            }
        );
    } );
} );
