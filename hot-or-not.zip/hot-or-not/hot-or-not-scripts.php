<?php
/**
 * Enqueues scripts and styles for the plugin.
 */
function hot_or_not_enqueue_scripts() {
    wp_enqueue_script(
        'hot-or-not',
        plugins_url( '/js/hot-or-not.js', __FILE__ ),
        array( 'jquery' ),
        '1.0',
        true
    );

    wp_localize_script(
        'hot-or-not',
        'hotOrNotAjax',
        array(
            'ajaxurl' => admin_url( 'admin-ajax.php' ),
            'nonce' => wp_create_nonce( 'hot-or-not-nonce' ),
        )
    );

    wp_enqueue_style(
        'hot-or-not',
        plugins_url( '/css/hot-or-not.css', __FILE__ ),
        array(),
        '1.0'
    );
}
add_action( 'wp_enqueue_scripts', 'hot_or_not_enqueue_scripts' );
