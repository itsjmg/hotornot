<?php
/**
 * Outputs the HOT or NOT buttons for the current photo.
 */
function hot_or_not_buttons() {
    global $post;

    // Only display the buttons on photo pages
    if ( get_post_type( $post ) !== 'hot-or-not-photo' ) {
        return;
    }

    // Get the current user's vote for this photo
    $vote = get_post_meta( $post->ID, 'hot_or_not_vote', true );

    // Output the buttons
    echo '<div class="hot-or-not-buttons">';
    echo '<a href="#" class="hot-button' . ( $vote === 'hot' ? ' active' : '' ) . '">HOT</a>';
    echo '<a href="#" class="not-button' . ( $vote === 'not' ? ' active' : '' ) . '">NOT</a>';
    echo '</div>';
}
add_action( 'the_content', 'hot_or_not_buttons' );

/**
 * Saves the user's vote when they click a button.
 */
function hot_or_not_save_vote() {
    if ( isset( $_POST['hot_or_not_photo_id'] ) && isset( $_POST['hot_or_not_vote'] ) ) {
        $photo_id = absint( $_POST['hot_or_not_photo_id'] );
        $vote = sanitize_text_field( $_POST['hot_or_not_vote'] );

        update_post_meta( $photo_id, 'hot_or_not_vote', $vote );
    }
}
add_action( 'template_redirect', 'hot_or_not_save_vote' );

/**
 * Loads the next photo in the queue when the user clicks a button.
 */
function hot_or_not_load_next_photo() {
    if ( isset( $_POST['hot_or_not_current_photo_id'] ) && isset( $_POST['hot_or_not_vote'] ) ) {
        $current_photo_id = absint( $_POST['hot_or_not_current_photo_id'] );
        $vote = sanitize_text_field( $_POST['hot_or_not_vote'] );

        // Save the user's vote
        update_post_meta( $current_photo_id, 'hot_or_not_vote', $vote );

        // Get the IDs of all photos except the current one
        $args = array(
            'post_type' => 'hot-or-not-photo',
            'post__not_in' => array( $current_photo_id ),
            'meta_query' => array(
                'relation' => 'OR',
                array(
                    'key' => 'hot_or_not_vote',
                    'compare' => 'NOT EXISTS',
                ),
                array(
                    'key' => 'hot_or_not_vote',
                    'value' => '',
                    'compare' => '=',
                ),
            ),
        );
        $query = new WP_Query( $args );
        $next_photo_ids = wp_list_pluck( $query->posts, 'ID' );

        // If there are no more photos in the queue, redirect to the home page
        if ( empty( $next_photo_ids ) ) {
            wp_redirect( home_url() );
            exit;
        }

        // Load a random photo from the queue
        $next_photo_id = $next_photo_ids[array_rand( $next_photo_ids )];
        $next_photo_url = get_the_post_thumbnail_url( $next_photo_id, 'full' );

        // Output the photo and voting buttons
        $output = array(
            'photo_url' => $next_photo_url,
            'photo_id' => $next_photo_id,
        );
        wp_send_json_success( $output );
    }
}
add_action( 'wp_ajax_hot_or_not_load_next_photo', 'hot_or_not_load_next_photo' );
