<?php
/**
 * Adds a settings page to the WordPress admin menu.
 */
function hot_or_not_settings_page() {
    add_submenu_page(
        'edit.php?post_type=hot-or-not-photo',
        __( 'HOT or NOT Settings', 'hot-or-not' ),
        __( 'Settings', 'hot-or-not' ),
        'manage_options',
        'hot-or-not-settings',
        'hot_or_not_settings_page_callback'
    );
}
add_action( 'admin_menu', 'hot_or_not_settings_page' );

/**
 * Renders the settings page.
 */
function hot_or_not_settings_page_callback() {
    ?>
    <div class="wrap">
        <h1><?php echo esc_html( get_admin_page_title() ); ?></h1>
        <form action="options.php" method="post">
            <?php settings_fields( 'hot_or_not_options' ); ?>
            <?php do_settings_sections( 'hot-or-not-settings' ); ?>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}

/**
 * Registers the plugin's settings.
 */
function hot_or_not_register_settings() {
    register_setting(
        'hot_or_not_options',
        'hot_or_not_image_size',
        array(
            'type' => 'string',
            'sanitize_callback' => 'hot_or_not_sanitize_image_size',
            'default' => 'medium',
        )
    );

    add_settings_section(
        'hot_or_not_general',
        __( 'General Settings', 'hot-or-not' ),
        '__return_false',
        'hot-or-not-settings'
    );

    add_settings_field(
        'hot_or_not_image_size',
        __( 'Image Size', 'hot-or-not' ),
        'hot_or_not_image_size_callback',
        'hot-or-not-settings',
        'hot_or_not_general'
    );
}
add_action( 'admin_init', 'hot_or_not_register_settings' );

/**
 * Sanitizes the image size setting.
 */
function hot_or_not_sanitize_image_size( $size ) {
    if ( ! in_array( $size, array( 'thumbnail', 'medium', 'large', 'full' ) ) ) {
        $size = 'medium';
    }

    return $size;
}

/**
 * Renders the image size setting field.
 */
function hot_or_not_image_size_callback() {
    $image_size = get_option( 'hot_or_not_image_size', 'medium' );
    ?>
    <select name="hot_or_not_image_size">
        <option value="thumbnail"<?php selected( $image_size, 'thumbnail' ); ?>><?php esc_html_e( 'Thumbnail' ); ?></option>
        <option value="medium"<?php selected( $image_size, 'medium' ); ?>><?php esc_html_e( 'Medium' ); ?></option>
        <option value="large"<?php selected( $image_size, 'large' ); ?>><?php esc_html_e( 'Large' ); ?></option>
        <option value="full"<?php selected( $image_size, 'full' ); ?>><?php esc_html_e( 'Full' ); ?></option>
    </select>
    <?php
}
